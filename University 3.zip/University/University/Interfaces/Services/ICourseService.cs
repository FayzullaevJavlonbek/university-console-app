﻿using System;
using University.Interfaces.Common;
using University.Models;
using University.ViewModels;

namespace University.Interfaces.Services
{
    public interface ICourseService : ICreateable<Course>, IReadable<CourseViewModel>
                                        
    {

    }
}

