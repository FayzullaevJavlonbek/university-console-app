﻿using System;
using University.Interfaces.Common;
using University.Models;

namespace University.Interfaces.Repositories
{
    public interface ICourseRepository: ICreateable<Course>,
        IDeleteable<Course>, IUpdateable<Course>, IReadable<Course>
    {
    }
}

