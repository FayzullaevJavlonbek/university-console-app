﻿using System;
using University.Interfaces.Common;
using University.Models;

namespace University.Interfaces.Repositories
{
    public interface IStudentRepository : ICreateable<Student>, ISearchable<Student>,
        IDeleteable<Student>, IUpdateable<Student>, IReadable<Student>
    {
        object GetAsync(string studentId);
    }
}

