﻿using System;
using University.Interfaces.Common;
using University.Models;

namespace University.Interfaces.Repositories
{
    public interface IStaffRepository:ICreateable<Staff>, IReadable<Staff>,
        IDeleteable<Staff>, ISearchable<Staff>, IUpdateable<Staff> 
    {
    }
}

