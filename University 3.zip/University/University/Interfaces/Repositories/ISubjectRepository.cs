﻿using System;
using University.Interfaces.Common;
using University.Models;

namespace University.Interfaces.Repositories
{
    public interface ISubjectRepository:ICreateable<Subject>, IDeleteable<Subject>,
                                        IReadable<Subject>, IUpdateable<Subject>
                                        
    {
    }
}

