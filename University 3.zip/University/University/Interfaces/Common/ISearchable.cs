﻿using System;
namespace University.Interfaces
{
    public interface ISearchable<T>
    {
        Task<T> SearchAsync(int id);
    }
}

