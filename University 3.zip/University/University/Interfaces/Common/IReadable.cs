﻿using System;
namespace University.Interfaces.Common
{
    public interface IReadable<T>
    {
        Task<IList<T>> GetAllAsync();
        Task<T> GetAsync(int id);
    }
}

