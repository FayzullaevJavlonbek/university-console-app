﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Students
{
    public class CreatePage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                Student student = new Student();

                Console.WriteLine("---------------Adding a new student--------------------");
                Console.Write("Enter a new id: ");
                student.Id = int.Parse(Console.ReadLine());

                Console.Write("Enter a new name: ");
                student.Name = Console.ReadLine();


                Console.Write("Enter a phone number: ");
                student.PhoneNumber = Console.ReadLine();

                Console.Write("Enter an address: ");
                student.Address = Console.ReadLine();


                IStudentRepository studentRepository = new StudentRepository();
                await studentRepository.CreateAsync(student);

                MessageHelper.Success("Successfully added");
                await RedirectToMainPage.GoBack();
            }
            catch
            {
                await Run();
            }
        }
    }
}

