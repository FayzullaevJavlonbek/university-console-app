﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Students
{
    public class UpdatePage
    {
        public static async Task Run()
        {

            
            try
            {

                Student student = new Student();
                Console.Clear();
                Console.WriteLine("Which Id you want to update: ");
                student.Id = int.Parse(Console.ReadLine());
                IStudentRepository studentRepository = new StudentRepository();
                var sampleStudent = await studentRepository.GetAsync(student.Id);

                if (sampleStudent is not null)
                {
                    Console.WriteLine("Enter updated name: ");
                    student.Name = Console.ReadLine()!;

                    Console.WriteLine("Enter updated phone number: ");
                    student.PhoneNumber = Console.ReadLine()!;

                    Console.WriteLine("Enter updated address: ");
                    student.Address = Console.ReadLine()!;

                    await studentRepository.UpdateAsync(student.Id, student);
                    MessageHelper.Success("Successfully updated");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await RedirectToMainPage.GoBack();
                }
            } catch
            {
                await Run();
            }
        }
    }
}


       



     


