﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Students
{
    public class DeletePage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Phone", "Address");
                IStudentRepository studentRepository = new StudentRepository();
                var students = await studentRepository.GetAllAsync();
                foreach (var student in students)
                {
                    consoleTable.AddRow(student.Id, student.Name, student.PhoneNumber, student.Address);
                }
                consoleTable.Write();

                Console.Write("Enter Id that you want to delete or '0' to go back: ");
                int id = int.Parse(Console.ReadLine());
                if (id == 0)
                {
                    await RedirectToMainPage.GoBack();
                }

                bool studentId = (students.FirstOrDefault(x => x.Id == id) != null);
                if (studentId)
                {
                    await studentRepository.DeleteAsync(id);
                    MessageHelper.Success("Successfully deleted");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
            }catch
            {
                await Run();
            }
            
            }

        }
    }


