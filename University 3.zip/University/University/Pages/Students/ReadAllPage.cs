﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Students
{
    public class ReadAllPage
    {
        public static async Task Run()
        {
            Console.Clear();
            ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Phone", "Address");
            IStudentRepository studentRepository = new StudentRepository();
            var students = await studentRepository.GetAllAsync();
            foreach(var student in students)
            {
                consoleTable.AddRow(student.Id, student.Name, student.PhoneNumber, student.Address);
            }
            consoleTable.Write();
            await RedirectToMainPage.GoBack();
        }
    }
}

