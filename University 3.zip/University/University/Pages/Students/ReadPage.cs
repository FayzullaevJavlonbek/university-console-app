﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Students
{
    public class ReadPage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                Console.Write("Enter a student Id: ");
                int id = int.Parse(Console.ReadLine());

                ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Phone", "Address");
                IStudentRepository studentRepository = new StudentRepository();
                var student = await studentRepository.GetAsync(id);
                if (student is not null)
                {
                    consoleTable.AddRow(student.Id, student.Name, student.PhoneNumber, student.Address);
                    consoleTable.Write();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
                await RedirectToMainPage.GoBack();

            }
            catch
            {
                await Run();
            }
        }
    }
}

