﻿using System;
using University.Helper;
using University.Pages.Students;

namespace University.Pages
{
    public class StudentPage
    {
        public static async Task Run()
        {
            Console.Clear();
            string[] text = { "Show All Students", "Find A Student by Id", "Add Student", "Delete Student", "Update Student", "Back" };
            Navigator navigator = new Navigator(text);
            var choose = navigator.Run();
            if (choose == 0)
            {
                await ReadAllPage.Run();
            }
            else if (choose == 1)
            {
                await ReadPage.Run();
            }
            else if (choose == 2)
            {
                await CreatePage.Run();
            }
            else if (choose == 3)
            {
                await DeletePage.Run();
            }
            else if (choose == 4)
            {
                await UpdatePage.Run();
            }
            else if (choose == 5)
            {
                await MainPage.Run();
            }
            else
            {
                MessageHelper.Error("Id");
            }
        }
    }
}


