﻿using System;
using University.Helper;
using University.Pages.Subjects;

namespace University.Pages
{
    public class SubjectPage
    {
        public static async Task Run()
        {
            Console.Clear();
            string[] text = { "Show All Subject", "Find A Subject by Id", "Add Subject", "Delete Subject", "Update Subject", "Back" };
            Navigator navigator = new Navigator(text);
            var choose = navigator.Run();
            if (choose == 0)
            {
                await ReadAllPage.Run();
            }
            else if (choose == 1)
            {
                await ReadPage.Run();
            }
            else if (choose == 2)
            {
                await CreatePage.Run();
            }
            else if (choose == 3)
            {
                await DeletePage.Run();
            }
            else if (choose == 4)
            {
                await UpdatePage.Run();
            }
            else if (choose == 5)
            {
                await MainPage.Run();
            }
            else
            {
                MessageHelper.Error("Id");
            }
        }
    }
}

