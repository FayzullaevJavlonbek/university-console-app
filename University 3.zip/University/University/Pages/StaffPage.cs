﻿using System;
using University.Helper;
using University.Pages.Staffs;

namespace University.Pages
{
    public class StaffPage
    {
        public static async Task Run()
        {
            string[] text = { "Show All Staff", "Find A Staff by Id", "Add Staff", "Delete Staff", "Update Staff", "Back" };
            Navigator navigator = new Navigator(text);
            var choose = navigator.Run();
            if (choose == 0)
            {
                await ReadAllPage.Run();
            }
            else if (choose == 1)
            {
                await ReadPage.Run();
            }
            else if (choose == 2)
            {
                await CreatePage.Run();
            }
            else if (choose == 3)
            {
                await DeletePage.Run();
            }
            else if (choose == 4)
            {
                await UpdatePage.Run();
            }
            else if (choose == 5)
            {
                await MainPage.Run();
            }
            else
            {
                MessageHelper.Error("Id");
            }
        }
    }
}

