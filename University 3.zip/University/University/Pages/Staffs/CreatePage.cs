﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Staffs;

public class CreatePage
{
    public static async Task Run()
    {
        Console.Clear();
        Staff staff = new Staff();
        Console.WriteLine("---------------Adding a new staff--------------------");
        try
        {
            Console.Write("Enter a new id: ");
            staff.Id = int.Parse(Console.ReadLine());

            Console.Write("Enter a new name: ");
            staff.Name = Console.ReadLine();
        newLevel:
            Console.WriteLine("Select a new level: ");
            Console.WriteLine("1. Middle_Lecturer\t2. PhD_Lecturer\t3. Senior_Lecturer");
            int choose = int.Parse(Console.ReadLine());
            if (choose == 1)
            {
                staff.staffPosition = Enums.StaffPosition.Middle_Lecturer;
            }
            else if (choose == 2)
            {
                staff.staffPosition = Enums.StaffPosition.PhD_Lecturer;
            }
            else if (choose == 3)
            {
                staff.staffPosition = Enums.StaffPosition.Senior_Lecturer;
            }

            else
            {
                MessageHelper.Error("Course");
                goto newLevel;
            }

            Console.Write("Enter a phone number: ");
            staff.PhoneNumber = Console.ReadLine();

            Console.Write("Enter an address: ");
            staff.Address = Console.ReadLine();


            IStaffRepository staffRepository = new StaffRepository();
            await staffRepository.CreateAsync(staff);

            MessageHelper.Success("Successfully added");
            await RedirectToMainPage.GoBack();
        } catch
        {
            await Run();
        }
    }
}

