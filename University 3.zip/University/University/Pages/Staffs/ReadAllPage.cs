﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Staffs
{
    public class ReadAllPage
    {
        public static async Task Run()
        {
            //Console.Clear();
            ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Level", "Phone", "Address");

            IStaffRepository StaffRepository = new StaffRepository();
            var Staffs = await StaffRepository.GetAllAsync();
            foreach (var Staff in Staffs)
            {
                consoleTable.AddRow(Staff.Id, Staff.Name, Staff.staffPosition, Staff.PhoneNumber, Staff.Address);
            }
            consoleTable.Write();
            await RedirectToMainPage.GoBack();
        }
    }
}

