﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Staffs
{
    public class DeletePage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Level", "Phone", "Address");
                IStaffRepository StaffRepository = new StaffRepository();
                var Staffs = await StaffRepository.GetAllAsync();
                foreach (var Staff in Staffs)
                {
                    consoleTable.AddRow(Staff.Id, Staff.Name, Staff.staffPosition, Staff.PhoneNumber, Staff.Address);
                }
                consoleTable.Write();

                Console.Write("Enter Id that you want to delete or '0' to go back: ");
                int id = int.Parse(Console.ReadLine());
                if (id == 0)
                {
                    await RedirectToMainPage.GoBack();
                }

                bool StaffId = (Staffs.FirstOrDefault(x => x.Id == id) != null);
                if (StaffId)
                {
                    await StaffRepository.DeleteAsync(id);
                    MessageHelper.Success("Successfully deleted");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
            } catch
            {
                await Run();
            }

        }

    }
}

