﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Staffs
{
    public class UpdatePage
    {
        public static async Task Run()
        {

            //var staffs = await staffRepository.GetAllAsync();
            Console.Clear();
            Staff staff = new Staff();
            Console.Clear();
            Console.WriteLine("Which Id you want to update: ");
            try
            {
                staff.Id = int.Parse(Console.ReadLine());
                IStaffRepository staffRepository = new StaffRepository();
                var samplestaff = await staffRepository.GetAsync(staff.Id);

                if (samplestaff is not null)
                {
                    Console.WriteLine("Enter updated name: ");
                    staff.Name = Console.ReadLine()!;

                EnterLevel:
                    Console.WriteLine("Enter updated level: ");
                    Console.WriteLine("1. Middle_Lecturer\t2. PhD_Lecturer\t3. Senior_Lecturer");
                    int choose = int.Parse(Console.ReadLine());
                    if (choose == 1)
                    {
                        staff.staffPosition = Enums.StaffPosition.Middle_Lecturer;
                    }
                    else if (choose == 2)
                    {
                        staff.staffPosition = Enums.StaffPosition.PhD_Lecturer;
                    }
                    else if (choose == 3)
                    {
                        staff.staffPosition = Enums.StaffPosition.Senior_Lecturer;

                    }
                    else
                    {
                        goto EnterLevel;
                    }

                    Console.WriteLine("Enter updated phone number: ");
                    staff.PhoneNumber = Console.ReadLine()!;

                    Console.WriteLine("Enter updated address: ");
                    staff.Address = Console.ReadLine()!;

                    await staffRepository.UpdateAsync(staff.Id, staff);
                    MessageHelper.Success("Successfully updated");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await RedirectToMainPage.GoBack();
                }
            }
            catch
            {
                await Run();
            }
        }
    }

}