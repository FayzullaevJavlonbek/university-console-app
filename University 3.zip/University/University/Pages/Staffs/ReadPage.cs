﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Staffs
{
    public class ReadPage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                Console.Write("Enter a staff Id: ");
                int id = int.Parse(Console.ReadLine());

                ConsoleTable consoleTable = new ConsoleTable("Id", "Full Name", "Level", "Phone", "Address");
                IStaffRepository staffRepository = new StaffRepository();
                var staff = await staffRepository.GetAsync(id);
                if (staff is not null)
                {
                    consoleTable.AddRow(staff.Id, staff.Name, staff.staffPosition, staff.PhoneNumber, staff.Address);
                    consoleTable.Write();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
                await RedirectToMainPage.GoBack();
            } catch
            {
                await Run();
            }
        }
    }
}

