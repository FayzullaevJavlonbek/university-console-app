﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Interfaces.Services;
using University.Repositories;
using University.Services;
using University.ViewModels;

namespace University.Pages.Courses
{
    public class ReadAllPage
    {
        public static async Task Run()
        {
            Console.Clear();
            ConsoleTable consoleTable = new ConsoleTable("Id", "Student ", "Subject ", "Lecturer");

            ICourseService courseService = new CourseService();
            var courseViewModels = await courseService.GetAllAsync();
            foreach (var courseViewModel in courseViewModels)
            {
                consoleTable.AddRow(courseViewModel.Id, courseViewModel.StudentName, courseViewModel.SubjectName, courseViewModel.StaffName);
            }
            consoleTable.Write();
            await RedirectToMainPage.GoBack();

            
        }
    }
}

