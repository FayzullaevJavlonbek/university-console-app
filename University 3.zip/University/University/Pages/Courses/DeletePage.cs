﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Courses
{
    public class DeletePage
    {
        public static async Task Run()
        {
            try
            {
                //Console.Clear();
                ConsoleTable consoleTable = new ConsoleTable("Id", "Student Id", "Lecturer Id");

                ICourseRepository courseRepository = new CourseRepository();
                var courses = await courseRepository.GetAllAsync();
                foreach (var course in courses)
                {
                    consoleTable.AddRow(course.Id, course.StudentId, course.LecturerId);
                }
                consoleTable.Write();

                Console.Write("Enter Id that you want to delete or '0' to go back: ");
                int id = int.Parse(Console.ReadLine());
                if (id == 0)
                {
                    await RedirectToMainPage.GoBack();
                }

                bool courseId = (courses.FirstOrDefault(x => x.Id == id) != null);
                if (courseId)
                {
                    await courseRepository.DeleteAsync(id);
                    MessageHelper.Success("Successfully deleted");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
            } catch
            {
                await Run();
            }

        }

    }
}

