﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Courses
{
    public class CreatePage
    {
        public static async Task Run()
        {
            try
            {
                //Console.Clear();
                Course course = new Course();
                Console.WriteLine("---------------Adding a new course--------------------");
                Console.Write("Enter a new id: ");
                course.Id = int.Parse(Console.ReadLine());

                Console.Write("Enter a new studentId: ");
                course.StudentId = int.Parse(Console.ReadLine());


                Console.Write("Enter a new LecturerId: ");
                course.LecturerId = int.Parse(Console.ReadLine());


                ICourseRepository courseRepository = new CourseRepository();
                await courseRepository.CreateAsync(course);

                MessageHelper.Success("Successfully added");
                await RedirectToMainPage.GoBack();
            }
            catch
            {
                await Run();
            }
        }
    }
}

