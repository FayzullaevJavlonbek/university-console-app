﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Courses
{
    public class UpdatePage
    {
        public static async Task Run()
        {

            //var courses = await courseRepository.GetAllAsync();
            try
            {

                //Console.Clear();
                Course course = new Course();
                Console.WriteLine("Which Id you want to update: ");
                course.Id = int.Parse(Console.ReadLine());
                ICourseRepository courseRepository = new CourseRepository();
                var samplecourse = await courseRepository.GetAsync(course.Id);

                if (samplecourse is not null)
                {
                    Console.WriteLine("Enter updated student Id: ");
                    course.StudentId = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter updated lecturer Id: ");
                    course.LecturerId = int.Parse(Console.ReadLine());


                    await courseRepository.UpdateAsync(course.Id, course);
                    MessageHelper.Success("Successfully updated");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await RedirectToMainPage.GoBack();
                }
            } catch
            {
                await Run();
            }
        }
    }

}

