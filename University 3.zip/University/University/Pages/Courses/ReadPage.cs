﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Interfaces.Services;
using University.Repositories;
using University.Services;

namespace University.Pages.Courses
{
    public class ReadPage
    {
        public static async Task Run()
        {
            try
            {
                //Console.Clear();
                Console.Write("Enter a course Id: ");
                int id = int.Parse(Console.ReadLine());

                ConsoleTable consoleTable = new ConsoleTable("Id", "Student ", "Lecturer ");
                ICourseService courseService = new CourseService();
                var course = await courseService.GetAsync(id);
                if (course is not null)
                {
                    consoleTable.AddRow(course.Id, course.StudentName, course.StaffName);
                    consoleTable.Write();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
                await RedirectToMainPage.GoBack();

            }
            catch
            {
                await Run();
            }
        }
    }
}

