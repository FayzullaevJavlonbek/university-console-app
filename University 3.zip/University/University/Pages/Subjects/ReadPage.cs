﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Subjects
{
    public class ReadPage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                Console.Write("Enter a subject Id: ");
                int id = int.Parse(Console.ReadLine());

                ConsoleTable consoleTable = new ConsoleTable("Id", "Subject");
                ISubjectRepository subjectRepository = new SubjectRepository();
                var subject = await subjectRepository.GetAsync(id);
                if (subject is not null)
                {
                    consoleTable.AddRow(subject.Id, subject.Name);
                    consoleTable.Write();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
                await RedirectToMainPage.GoBack();

            }
            catch
            {
                await Run();
            }
        }
    }
}

