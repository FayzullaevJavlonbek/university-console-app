﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Subjects
{
    public class DeletePage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                ConsoleTable consoleTable = new ConsoleTable("Id", "Subject");
                ISubjectRepository subjectRepository = new SubjectRepository();
                var subjects = await subjectRepository.GetAllAsync();
                foreach (var subject in subjects)
                {
                    consoleTable.AddRow(subject.Id, subject.Name);
                }
                consoleTable.Write();

                Console.Write("Enter Id that you want to delete or '0' to go back: ");
                int id = int.Parse(Console.ReadLine());
                if (id == 0)
                {
                    await RedirectToMainPage.GoBack();
                }

                bool subjectId = (subjects.FirstOrDefault(x => x.Id == id) != null);
                if (subjectId)
                {
                    await subjectRepository.DeleteAsync(id);
                    MessageHelper.Success("Successfully deleted");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await Run();
                }
            }
            catch
            {
                await Run();
            }

        }

    }
}


