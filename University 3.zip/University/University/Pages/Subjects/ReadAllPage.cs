﻿using System;
using ConsoleTables;
using University.Helper;
using University.Interfaces.Repositories;
using University.Repositories;

namespace University.Pages.Subjects
{
    public class ReadAllPage
    {
        public static async Task Run()
        {
            Console.Clear();
            ConsoleTable consoleTable = new ConsoleTable("Id", "Subject");
            ISubjectRepository subjectRepository = new SubjectRepository();
            var subjects = await subjectRepository.GetAllAsync();
            foreach (var subject in subjects)
            {
                consoleTable.AddRow(subject.Id, subject.Name);
            }
            consoleTable.Write();
            await RedirectToMainPage.GoBack();
        }
    }
}

