﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Subjects
{
    public class UpdatePage
    {
        public static async Task Run()
        {


            try
            {

                Subject subject = new Subject();
                Console.Clear();
                Console.WriteLine("Which Id you want to update: ");
                subject.Id = int.Parse(Console.ReadLine());
                ISubjectRepository subjectRepository = new SubjectRepository();
                var samplesubject = await subjectRepository.GetAsync(subject.Id);

                if (samplesubject is not null)
                {
                    Console.WriteLine("Enter updated name: ");
                    subject.Name = Console.ReadLine()!;

                    

                    await subjectRepository.UpdateAsync(subject.Id, subject);
                    MessageHelper.Success("Successfully updated");
                    await RedirectToMainPage.GoBack();
                }
                else
                {
                    MessageHelper.Error("Id");
                    await RedirectToMainPage.GoBack();
                }
            }
            catch
            {
                await Run();
            }
        }
    }
}

