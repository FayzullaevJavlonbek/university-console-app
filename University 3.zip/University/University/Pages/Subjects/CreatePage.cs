﻿using System;
using University.Helper;
using University.Interfaces.Repositories;
using University.Models;
using University.Repositories;

namespace University.Pages.Subjects
{
    public class CreatePage
    {
        public static async Task Run()
        {
            try
            {
                Console.Clear();
                Subject subject = new Subject();

                Console.WriteLine("---------------Adding a new subject--------------------");
                Console.Write("Enter a new id: ");
                subject.Id = int.Parse(Console.ReadLine());

                Console.Write("Enter a new name: ");
                subject.Name = Console.ReadLine();


               

                ISubjectRepository subjectRepository = new SubjectRepository();
                await subjectRepository.CreateAsync(subject);

                MessageHelper.Success("Successfully added");
                await RedirectToMainPage.GoBack();
            }
            catch
            {
                await Run();
            }
        }
    }
}

