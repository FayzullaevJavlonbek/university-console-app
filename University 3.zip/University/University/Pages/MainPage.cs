﻿using System;
using University.Helper;

namespace University.Pages
{
    public class MainPage
    {
        public static async Task Run()
        {
            Console.Clear();
            string[] text = { "Staff", "Students","Subject" ,"Courses","Finish"};
            Navigator navigator = new Navigator(text);
            var choose = navigator.Run();
            if (choose == 0)
            {  
                await StaffPage.Run();
            }
            else if(choose == 1)
            {
                await StudentPage.Run();
                
            } else if (choose == 2)
            {
                await SubjectPage.Run();

            } else if (choose == 3)
            {
                await CoursePage.Run();
            } else if (choose == 4)
            {
                Environment.Exit(0);
            }


        }
        
        
    }
}

