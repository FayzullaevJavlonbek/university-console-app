﻿using System;
using University.Enums;

namespace University.Models
{
    public class Course
    {
        public int Id { get; set; }
        public int SubjectId { get; set; }
        public int StudentId { get; set; }
        public int LecturerId { get; set; }
      
    }
}

