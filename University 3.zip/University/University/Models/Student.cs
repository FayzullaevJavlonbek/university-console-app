﻿using System;
using University.Enums;

namespace University.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; } = String.Empty;
        public string PhoneNumber { get; set; } = String.Empty;
        public string Address { get; set; } = String.Empty;
        
    }
}

