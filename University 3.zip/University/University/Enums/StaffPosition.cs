﻿using System;
namespace University.Enums
{
    public enum StaffPosition
    {
        Middle_Lecturer, Senior_Lecturer, PhD_Lecturer
    }
}

