﻿using System;
using University.Interfaces.Common;
using University.Interfaces.Repositories;
using University.Interfaces.Services;
using University.Models;
using University.Repositories;
using University.ViewModels;

namespace University.Services
{
    public class CourseService: ICourseService
    {
        private readonly ICourseRepository courseRepository;
        private readonly IStudentRepository studentRepository;
        private readonly IStaffRepository staffRepository;
        private readonly ISubjectRepository subjectRepository;

        public CourseService()
        {
            courseRepository = new CourseRepository();
            studentRepository = new StudentRepository();
            staffRepository = new StaffRepository();
            subjectRepository = new SubjectRepository();
        }

        public Task<bool> CreateAsync(Course obj)
        {
            throw new NotImplementedException();
        }

        public async Task<IList<CourseViewModel>> GetAllAsync()
        {
            IList<CourseViewModel> resultList = new List<CourseViewModel>();
            var courses = await courseRepository.GetAllAsync();
            foreach(var course in courses)
            {
                CourseViewModel courseViewModel = new CourseViewModel();
                courseViewModel.Id = course.Id;
                courseViewModel.StudentName = (await studentRepository.GetAsync(course.StudentId)).Name;
                courseViewModel.SubjectName = (await subjectRepository.GetAsync(course.SubjectId)).Name;
                courseViewModel.StaffName = (await staffRepository.GetAsync(course.LecturerId)).Name;
                resultList.Add(courseViewModel);
            }
            return resultList;
        }


        //public async Task<IList<OrderViewModel>> GetAllAsync()
        //{
        //    IList<OrderViewModel> resultList = new List<OrderViewModel>();
        //    var orders = await orderRepository.GetAllAsync();
        //    foreach (var order in orders)
        //    {
        //        OrderViewModel orderViewModel = new OrderViewModel();
        //        orderViewModel.Id = order.Id;
        //        orderViewModel.ClientName = (await clientRepository.GetAsync(order.ClientId)).Name;
        //        orderViewModel.ProductName = (await productRepository.GetAsync(order.ProductId)).Name;
        //        orderViewModel.SellerName = (await sellerRepository.GetAsync(order.SellerId)).Name;
        //        orderViewModel.ProductCount = order.Count;
        //        orderViewModel.Date = order.Date;
        //        orderViewModel.TotalSum = order.TotalSum;
        //        resultList.Add(orderViewModel);
        //    }
        //    return resultList;
        //}
        public Task<Course> GetAsync(int id)
        {
            throw new NotImplementedException();
        }

        Task<CourseViewModel> IReadable<CourseViewModel>.GetAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}

