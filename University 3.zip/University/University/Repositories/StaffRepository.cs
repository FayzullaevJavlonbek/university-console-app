﻿using System;
using Newtonsoft.Json;
using University.Constants;
using University.Interfaces.Repositories;
using University.Models;

namespace University.Repositories
{
    public class StaffRepository : IStaffRepository
    {
        private readonly string _dbPath = DbConstants.StaffDbPath;

        public async Task<bool> CreateAsync(Staff obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                list.Add(obj);
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        list.Remove(item);
                        break;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;

            }
            catch
            {
                return false;
            }
        }

        public async Task<IList<Staff>> GetAllAsync()
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                return list;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Staff> GetAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Staff> SearchAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> UpdateAsync(int id, Staff obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Staff>>(json);
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].Id == id)
                    {
                        list[i] = obj;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            }
            catch
            {
                return false;
            }


        }

    }
}

