﻿using System;
using Newtonsoft.Json;
using University.Constants;
using University.Interfaces.Repositories;
using University.Models;

namespace University.Repositories
{     
    public class StudentRepository : IStudentRepository
    {
        private readonly string _dbPath = DbConstants.StudentDbPath;

        public async Task<bool> CreateAsync(Student obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                list.Add(obj);
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            } catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                foreach(var item in list)
                {
                    if (item.Id == id)
                    {
                        list.Remove(item);
                        break;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;

            }
            catch
            {
                return false;
            }
        }

        public async Task<IList<Student>> GetAllAsync()
        {
            try
            {
                string json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                return list;
            }catch
            {
                return null;
            }
        }

        public async Task<Student> GetAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public object GetAsync(string studentId)
        {
            throw new NotImplementedException();
        }

        public async Task<Student> SearchAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        return item;
                    }
                }
                return null;
            } catch
            {
                return null;
            }
        }

        public async Task<bool> UpdateAsync(int id, Student obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Student>>(json);
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].Id == id)
                    {
                        list[i] = obj;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            }catch
            {
                return false;
            }
           
           
        }
    }
}

