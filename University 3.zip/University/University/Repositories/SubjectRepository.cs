﻿using System;
using Newtonsoft.Json;
using University.Constants;
using University.Interfaces.Repositories;
using University.Models;

namespace University.Repositories
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly string _dbPath = DbConstants.SubjectDbPath;

        public async Task<bool> CreateAsync(Subject obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Subject>>(json);
                list.Add(obj);
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Subject>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        list.Remove(item);
                        break;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;

            }
            catch
            {
                return false;
            }
        }

        public async Task<IList<Subject>> GetAllAsync()
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Subject>>(json);
                return list;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Subject> GetAsync(int id)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Subject>>(json);
                foreach (var item in list)
                {
                    if (item.Id == id)
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }


        public async Task<bool> UpdateAsync(int id, Subject obj)
        {
            try
            {
                var json = await File.ReadAllTextAsync(_dbPath);
                var list = JsonConvert.DeserializeObject<List<Subject>>(json);
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].Id == id)
                    {
                        list[i] = obj;
                    }
                }
                json = JsonConvert.SerializeObject(list);
                await File.WriteAllTextAsync(_dbPath, json);
                return true;
            }
            catch
            {
                return false;
            }


        }
    }
}

