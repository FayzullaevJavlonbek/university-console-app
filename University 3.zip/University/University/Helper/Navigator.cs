﻿using System;
namespace University.Helper
{
    public class Navigator
    {
        private string[] Options;
        public int selectedIndex;

        public Navigator(string[] options)
        {
            Options = options;
            selectedIndex = 0;
        }
        public void DisplayOptions()
        {
            for (int i = 0; i < Options.Length; i++)
            {
                string currentOptions = Options[i];
                string prefix;
                if (i == selectedIndex)
                {
                    prefix = ">>";
                    
                }
                else
                {
                    prefix = "  ";
                   
                }
                Console.WriteLine($"{prefix} ||{currentOptions} ");
            }
            Console.ResetColor();
        }
        public int Run()
        {
            ConsoleKey keyPressed;
            do
            {
                Console.Clear();
                DisplayOptions();
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                keyPressed = keyInfo.Key;
                if (keyPressed == ConsoleKey.UpArrow)
                {
                    selectedIndex--;
                    if (selectedIndex == -1)
                    {
                        selectedIndex = Options.Length - 1;
                    }
                }
                else if (keyPressed == ConsoleKey.DownArrow)
                {
                    selectedIndex++;
                    if (selectedIndex == Options.Length)
                    {
                        selectedIndex = 0;
                    }
                }
            } while (keyPressed != ConsoleKey.Enter);
            return selectedIndex;
        }

    }
}

