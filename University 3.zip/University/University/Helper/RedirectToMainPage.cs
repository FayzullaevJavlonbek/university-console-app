﻿using System;
using University.Pages;

namespace University.Helper
{
    public class RedirectToMainPage
    {

        public static async Task GoBack()
        {
            try
            {
                Console.WriteLine("Press '0' to go to Main Page");
                int choose = int.Parse(Console.ReadLine());
                if (choose == 0)
                {
                    await MainPage.Run();
                }
                else
                {

                }
            } catch
            {
                MessageHelper.Error("Enter correct value!!!");
            }
        }
    }
}

