﻿using System;
namespace University.Helper
{
    public class MessageHelper
    {
        public static void Error(string text)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(text + " is wrong input, please try again");
            Console.ForegroundColor = ConsoleColor.Black;
        }
        public static void Success(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(text);
            Console.ForegroundColor = ConsoleColor.Black;
        }
    }
}

