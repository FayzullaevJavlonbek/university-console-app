﻿using University.Repositories;
using University.Enums;
using University.Interfaces.Repositories;
using University.Models;
using University.Pages;

class Program
{
    public static async Task Main()
    {
        await MainPage.Run();
        //Course course = new Course()
        //{
        //    Id = 6,
        //    StudentId = 6,
        //    SubjectId = 6,
        //    LecturerId = 6
        //};
        //ICourseRepository courseRepository = new CourseRepository();
        //await courseRepository.CreateAsync(course);

        
    }
}