﻿using System;
namespace University.Constants
{
    public class DbConstants
    {
        public const string StudentDbPath = "Database/student.json";
        public const string StaffDbPath = "Database/staff.json";
        public const string CourseDbPath = "Database/course.json";
        public const string SubjectDbPath = "Database/subject.json";

    }
}

