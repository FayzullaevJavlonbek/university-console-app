﻿using System;
using University.Enums;

namespace University.ViewModels
{
    public class CourseViewModel
    {
        public int Id { get; set; }
        public string StudentName { get; set; } = String.Empty;
        public string SubjectName { get; set; } = String.Empty;
        public string StaffName { get; set; } = String.Empty;

    }
}

